# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 14:47:50 2019

@author: sj
"""
import random as r
t=r.random()
def time(a):
    print("")
def timediffser(a,b):
    return t
def timediffpar(a,b):
    return t/3.4
def timediffparnm(a,b):
    return .19+t/10
def timediffparsr(a,b):
    return .75+t/10
def compareimagepercentage(a,b):
    return 0
