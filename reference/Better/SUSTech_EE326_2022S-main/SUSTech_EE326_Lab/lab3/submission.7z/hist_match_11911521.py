import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np


def hist_match_11911521(input_image, spec_hist=None):
    img = np.array(cv.imread(input_image, cv.IMREAD_GRAYSCALE))
    m, n = img.shape
    L = 256
    bins = range(L + 1)
    input_hist, _ = np.histogram(img.flat, bins=bins, density=True)

    if spec_hist is None:
        spec_hist = np.array([1 / L] * L)

    s = np.array(np.zeros(L))
    for i in range(L):
        s[i] = np.round((L - 1) * sum(input_hist[:i + 1]))

    gz = np.array(np.zeros(L))
    for i in range(L):
        gz[i] = np.round((L - 1) * sum(spec_hist[:i + 1]))

    z = np.array(np.zeros(L))
    for i in range(L):
        z[i] = np.abs(gz - s[i]).argmin()

    output_image = np.array(np.zeros((m, n)))
    for i in range(m):
        for j in range(n):
            output_image[i][j] = z[img[i][j]]

    output_hist, _ = np.histogram(output_image.flat, bins=bins, density=True)

    return output_image, output_hist, input_hist


if __name__ == '__main__':
    path = 'Q3_2.tif'
    image = cv.imread("Q3_2.tif.", cv.IMREAD_GRAYSCALE)
    cv.imwrite("Q3_2.png", image)

    spec = np.array(cv.imread("Q3_4.tif.", cv.IMREAD_GRAYSCALE))
    spec_hist, _ = np.histogram(spec.flat, bins=256, density=True)

    [out_img_1, out_hist_1, in_hist_1] = hist_match_11911521(path, spec_hist)

    cv.imwrite("Q3_2_11911521.tif", out_img_1)
    cv.imwrite("Q3_2_11911521.png", out_img_1)

    image = cv.imread("Q3_2_11911521.tif", cv.IMREAD_GRAYSCALE)
    cv.imshow('Q3_2_11911521', image)
    cv.waitKey(0)

    plt.bar(range(256), out_hist_1)
    plt.title("out_hist")
    plt.savefig("Q3_2_out_hist.png")
    plt.show()
    plt.bar(range(256), in_hist_1)
    plt.title("in_hist")
    plt.savefig("Q3_2_in_hist.png")
    plt.show()
    plt.bar(range(256), spec_hist)
    plt.title("spec_hist")
    plt.savefig("Q3_2_spec_hist.png")
    plt.show()

    # plt.hist(in_hist_1)
    # plt.show()
    # plt.hist(out_hist_1)
    # plt.show()
