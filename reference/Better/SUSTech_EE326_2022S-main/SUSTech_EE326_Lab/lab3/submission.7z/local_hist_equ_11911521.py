import time

import cv2
import numpy as np
import matplotlib.pyplot as plt

def local_hist_equ_11911521(input_image, m_size=None):
    int_image = cv2.imread(input_image, cv2.IMREAD_GRAYSCALE)
    img = np.array(int_image)
    m, n = int_image.shape
    L = 256
    local_len = int((m_size-1) / 2)
    bins = range(L + 1)

    input_hist, _ = np.histogram(img.flat, bins=bins, density=True)

    s = np.array(np.zeros(L))
    output_image = np.array(np.zeros((m, n)))

    for i in range(m):
        for j in range(n):
            print("%d,%d" % (i, j))
            local = np.zeros((m_size, m_size))
            for k in range(i - local_len, i + local_len+1):
                for l in range(j - local_len, j + local_len+1):
                    if 0 <= k < m and 0 <= l < n:
                        local[k - (i - local_len), l - (j - local_len)] = img[k, l]

            local_hist, _ = np.histogram(local.flat, bins=bins, density=True)

            for k in range(L):
                s[k] = (L - 1) * sum(local_hist[:k + 1])

            output_image[i][j] = s[img[i][j]]

    output_hist, _ = np.histogram(output_image.flat, bins=bins, density=True)

    return output_image, output_hist, input_hist


if __name__ == '__main__':

    path = 'Q3_3.tif'
    image = cv2.imread("Q3_3.tif.", cv2.IMREAD_GRAYSCALE)
    cv2.imwrite("Q3_3.png", image)
    # path = 'rice.tif'
    t1 = time.time()
    [out_img_1, out_hist_1, in_hist_1] = local_hist_equ_11911521(path, 3)
    t2 = time.time()
    print("time:%f" % (t2-t1))
    cv2.imwrite("Q3_3_11911521.tif", out_img_1)
    cv2.imwrite("Q3_3_11911521.png", out_img_1)
    image = cv2.imread("Q3_3_11911521.tif", cv2.IMREAD_GRAYSCALE)
    cv2.imshow('image', image)
    cv2.waitKey(0)

    plt.bar(range(256), out_hist_1)
    plt.title("out_hist")
    plt.savefig("Q3_3_out_hist.png")
    plt.show()
    plt.bar(range(256), in_hist_1)
    plt.title("in_hist")
    plt.savefig("Q3_3_in_hist.png")
    plt.show()

